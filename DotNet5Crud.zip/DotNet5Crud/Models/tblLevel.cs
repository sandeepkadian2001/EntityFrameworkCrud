﻿using DotNet5Crud.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DotNet5Crud
{
    [Table("tblLevel")]
    public partial class tblLevel
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public tblLevel()
        {
        }

        [Key]
        public LevelId LevelId { get; set; }

        [StringLength(50)]
        public string LevelType { get; set; }

        public List<Employee> Employees { get; set; }
    }
}
