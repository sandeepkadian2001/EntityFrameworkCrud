﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DotNet5Crud.Models
{
    [Table("tblUserLevel")]
    public partial class tblUserLevel
    {
        [Key]
        public int UserLevelId { get; set; }

        [StringLength(50)]
        public string LevelDescription { get; set; }

        public int LevelId { get; set; }

        public int UserId { get; set; }

        public virtual tblLevel tblLevel { get; set; }

        public virtual tblUser tblUser { get; set; }
    }
}